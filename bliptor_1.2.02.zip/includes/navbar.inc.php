<br>
<br>
<br>

<div class="container">
    <div class="row justify-content-center">
        <form action="" method="POST" class="col-xl-6">
            <center>
                <a href="https://server.racoonpy.com/youtube/"><img src="assets/logos/logo.png" class="mb-3" width="180" alt=""></a>
            </center>
            <div class="input-group mb-3" id="searchbox" >
                <input type="text" class="form-control" name="url" placeholder="Enter video URL" required>
                <div class="input-group-append">
                    <button class="btn bg-second text-white" type="submit">Search</button>
                </div>
            </div>
            <h6 class="text-danger text-center"><?= !empty($info['error']) ? $info['error'] : '' ?></h6>
        </form>
    </div>
</div>
<h6 class="text-white text-center">YouTube Video Downloader</h6>