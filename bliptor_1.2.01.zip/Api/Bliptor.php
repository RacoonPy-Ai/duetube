<?php
/*
RacoonPy Youtube video downloader (API) Version: 1.2.16

ooooooooo.                                                       ooooooooo.               
`888   `Y88.                                                     `888   `Y88.             
 888   .d88'  .oooo.    .ooooo.   .ooooo.   .ooooo.  ooo. .oo.    888   .d88' oooo    ooo 
 888ooo88P'  `P  )88b  d88' `"Y8 d88' `88b d88' `88b `888P"Y88b   888ooo88P'   `88.  .8'  
 888`88b.     .oP"888  888       888   888 888   888  888   888   888           `88..8'   
 888  `88b.  d8(  888  888   .o8 888   888 888   888  888   888   888            `888'    
o888o  o888o `Y888""8o `Y8bod8P' `Y8bod8P' `Y8bod8P' o888o o888o o888o            .8'     
                                                                              .o..P'      
                                                                              `Y8P'
*/
class Bliptor{

    private $vide_id;
    private $secrect_key;
    
    /**
     * Extract youtube video_id from any piece of text
     * @param $str
     * @return string
     */
    private function get_video_ID($str)
    {
        if (strlen($str) === 11) {
            return $str;
        }

        if (preg_match('/(?:\/|%3D|v=|vi=)([a-z0-9_-]{11})(?:[%#?&]|$)/ui', $str, $matches)) {
            return $matches[1];
        }

        return false;
    }
    
    /**
     * @return mixed
     * Get video info
     */
    public function getInfo(){
        require_once 'config/configuration.php';
        $video_id = (isset($_POST['url']) ? $this->get_video_ID($_POST['url']) : '820ej4840');
        $secret_key = (!empty($config['SECRET_KEY'])) ? $config['SECRET_KEY'] : die('Please provide secret key.');
        $get_API = file_get_contents("https://api.racoonpy.com/security/youtube/{$video_id}/{$secret_key}");
        return json_decode($get_API,true);
    }
}

$api = new Bliptor();