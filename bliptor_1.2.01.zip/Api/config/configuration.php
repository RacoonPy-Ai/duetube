<?php
$config['SECRET_KEY'] = 'RP18000012';