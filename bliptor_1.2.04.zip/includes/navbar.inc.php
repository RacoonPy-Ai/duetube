
<div class="container-fluid bg-main py-5">
    <div class="container">
        <div class="row justify-content-center">
            <form action="" method="POST" class="col-xl-6">
                <center>
                    <a href="https://server.racoonpy.com/youtube/">
                        <h1><b>Duetube</b></h1>
                    </a>
                </center>
                <div class="input-group mb-3" id="searchbox" >
                    <input type="text" class="form-control" name="url" placeholder="Enter video URL" required>
                    <div class="input-group-append">
                        <button class="btn bg-second text-white" type="submit">Search</button>
                    </div>
                </div>
                <h6 class="text-danger text-center"><?= !empty($info['error']) ? $info['error'] : '' ?></h6>
                <h6 class="text-center">YouTube Video Downloader</h6>
            </form>
        </div>
    </div>
</div>