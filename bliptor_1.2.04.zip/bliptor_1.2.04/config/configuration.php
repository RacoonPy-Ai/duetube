<?php
$config['SECRET_KEY'] = 'RP1800003255';
$config['VIDEO_URL']  = 'DEMO';