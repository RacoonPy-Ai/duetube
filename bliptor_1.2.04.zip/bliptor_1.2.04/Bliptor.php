<?php
/*
RacoonPy Youtube video downloader (API) Version: 1.2.04

░█▀▄░█▀█░█▀▀░█▀█░█▀█░█▀█░█▀█░█░█
░█▀▄░█▀█░█░░░█░█░█░█░█░█░█▀▀░░█░
░▀░▀░▀░▀░▀▀▀░▀▀▀░▀▀▀░▀░▀░▀░░░░▀░
*/
class Bliptor{

    private $vide_id;
    private $secrect_key;
    
    /**
     * Extract youtube video_id from any piece of text
     * @param $str
     * @return string
     */
    private function get_video_ID($str)
    {
        if (strlen($str) === 11) {
            return $str;
        }

        if (preg_match('/(?:\/|%3D|v=|vi=)([a-z0-9_-]{11})(?:[%#?&]|$)/ui', $str, $matches)) {
            return $matches[1];
        }

        return false;
    }
    
    /**
     * @return mixed
     * Get video info
     */
    public function getInfo($url){
        require_once 'config/configuration.php';
        
        $video_id = (!empty($url)) ? $this->get_video_ID($url) : $config['VIDEO_URL'];

        $secret_key = (!empty($config['SECRET_KEY'])) ? $config['SECRET_KEY'] : '';
        $url = "https://api.racoonpy.com/security/youtube/{$secret_key}/{$video_id}";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_REFERER, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3000); // 3 sec.
        curl_setopt($ch, CURLOPT_TIMEOUT, 10000); // 10 sec.
        $result = curl_exec($ch);
        curl_close($ch);        
        return json_decode($result,true);
    }
}

$api = new Bliptor();