<?php
$config['SECRET_KEY'] = 'RP18000012';
$config['VIDEO_URL']  = 'DEMO';